#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("ShowTime");
    setWindowFlags(windowFlags()&~Qt::WindowMaximizeButtonHint);    // 禁止最大化按钮
    setFixedSize(this->width(),this->height());                     // 禁止拖动窗口大小

    p_Time=new QProcess;

    connect(p_Time, &QProcess::readyRead, this, &MainWindow::readTime);

    p_Time->start("./showTime");
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::readTime()
{
    ui->label_time->setText(QString(p_Time->readAll()));
}
