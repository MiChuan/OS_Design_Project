#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <stdio.h>
#include <time.h>
#include <unistd.h>
#include <bits/stdc++.h>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("ShowNum");
    setWindowFlags(windowFlags()&~Qt::WindowMaximizeButtonHint);    // 禁止最大化按钮
    setFixedSize(this->width(),this->height());                     // 禁止拖动窗口大小

    /*调用外部进程*/
    p_Num=new QProcess;

    connect(p_Num, &QProcess::readyRead, this, &MainWindow::readNum);

    p_Num->start("./Num");
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::readNum()
{
    char temp1[30];
    strcpy(temp1, p_Num->readAll().data());
    temp1[strlen(temp1)-1]='\0';
    double n;
    n = atoi(temp1);
    ui->lcdNumber->display(n);
}
