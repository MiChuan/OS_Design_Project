#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <stdlib.h>
#include <stdio.h>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("ThreeProgresses");
    setWindowFlags(windowFlags()&~Qt::WindowMaximizeButtonHint);    // 禁止最大化按钮
    setFixedSize(this->width(),this->height());                     // 禁止拖动窗口大小

    /*调用外部进程*/
    p_Num=new QProcess;
    p_Sum=new QProcess;
    p_Time=new QProcess;

    connect(p_Num, &QProcess::readyRead, this, &MainWindow::readNum);
    connect(p_Sum, &QProcess::readyRead, this, &MainWindow::readSum);
    connect(p_Time, &QProcess::readyRead, this, &MainWindow::readTime);

    p_Num->start("./showNum");
    p_Sum->start("./showSum");
    p_Time->start("./showTime");
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::readSum()
{
    char temp[30];
    strcpy(temp, p_Sum->readAll().data());
    temp[strlen(temp)-1]='\0';
    ui->label_sum->setText(QString(temp));
}

void MainWindow::readNum()
{
    char temp1[30];
    strcpy(temp1, p_Num->readAll().data());
    temp1[strlen(temp1)-1]='\0';
    double n;
    n = atoi(temp1);
    ui->lcdNumber->display(n);
}

void MainWindow::readTime()
{
    ui->label_time->setText(QString(p_Time->readAll()));
}
