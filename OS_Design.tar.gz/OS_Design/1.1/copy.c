#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/syscall.h>
#include <errno.h>

#define SIZE 1024   //每次读取字节数

int main(int argc, char *argv[]) {
    int source,goal;
    int length;
    char buff[SIZE];

    /*检查参数数目*/
    if(argc != 3){
        printf("argc error!\n");
        exit(1);
    }

    /*打开源文件*/
    source = open(argv[1],O_RDONLY);
    if(source < 0){
        printf("Fail to open %s!\n",argv[1]);
        exit(1);
    }

    /*打开目标文件*/
    goal = open(argv[2],O_WRONLY|O_CREAT,0666);
    if(goal < 0){
        printf("Fial to open %s!\n",argv[2]);
        exit(1);
    }

    /*拷贝源文件内容到目标文件*/
    while((length = read(source,buff,SIZE)) > 0){
        write(goal,buff,length);
    }
    printf("copy from %s to %s has finished!\n",argv[1],argv[2]);

    /*关闭文件*/
    close(source);
    close(goal);
    return 0;
}