// syscall_64.tbl
# mycalls 
333 64  hello_world     sys_hello_world
334 64  mycopy          sys_mycopy


// syscalls.h
/* my syscalls */
asmlinkage long sys_hello_world(void);
asmlinkage long sys_mycopy(const char __user *target, const char __user *source);


// sys.c
asmlinkage long sys_hello_world(void)
{
	printk("mycall: hello world !");
	return 0;
}

//#include <mm/util.c>
asmlinkage long sys_mycopy(const char __user *_target, const char __user *_source)
{
	char buf[512]; 
	int sor_fd, tar_fd, length;
	char * target = NULL;
	char * source = NULL;

	// kernel -> User space    -->  fs
	mm_segment_t fs;
	fs = get_fs();  //get access restriction value
	set_fs(get_ds());  //set kernel restriction value
	
	//get point, from user to kernel
	target = strndup_user(_target,PAGE_SIZE);
	if(IS_ERR(target)){
	    printk("point error!\n");
	    return -1;
	}
	
	source = strndup_user(_source,PAGE_SIZE);
	if(IS_ERR(source)){
	    printk("point error!\n");
	    return -1;
	}

	// open file
	sor_fd = sys_open(source, O_RDONLY, S_IRUSR);
	if (sor_fd == -1)
	{
		printk("copy: open %s error\n", source);
		return -1;
	}
	printk("open source success!\n");

	tar_fd = sys_open(target, O_WRONLY | O_CREAT, S_IRUSR | S_IWUSR);
	if (tar_fd == -1)
	{
		printk("copy: create %s error\n", target);
		return -1;
	}
	printk("open target success!\n");
	
	// copy file
	while((length = sys_read(sor_fd, buf, sizeof(buf))) > 0){
	    sys_write(tar_fd, buf, length);
	}
    printk("copy: copy %s complete\n", source);

	// close file
	sys_close(tar_fd);
	sys_close(sor_fd);
	set_fs(fs);   //recovery

	return 0;
}
