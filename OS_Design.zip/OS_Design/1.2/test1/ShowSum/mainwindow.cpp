#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("ShowSum");
    setWindowFlags(windowFlags()&~Qt::WindowMaximizeButtonHint);    // 禁止最大化按钮
    setFixedSize(this->width(),this->height());                     // 禁止拖动窗口大小

    p_Sum=new QProcess;

    connect(p_Sum, &QProcess::readyRead, this, &MainWindow::readSum);

    p_Sum->start("./Sum");
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::readSum()
{
    char temp[30];
    strcpy(temp, p_Sum->readAll().data());
    temp[strlen(temp)-1]='\0';
    ui->label_sum->setText(QString(temp));
}
